# PocketSmart AI

A complete FastAPI + Jinja2 + SQLite application based on the supplied PocketSmart AI specification. It provides Home Interior, Party, and Jewelry budget planners, user authentication, recommendation history, Gemini text/image generation, and deterministic fallback recommendations when Gemini is unavailable.

## Important implementation note

The supplied document names **Gemini 1.5 Flash Pro**. The application therefore exposes `GEMINI_MODEL` in `.env`. Set it to the model name enabled for your Google AI account. The rest of the application is model-agnostic.

## Features

- FastAPI backend with modular routes/services/models.
- Jinja2 responsive frontend.
- Registration, login, logout, JWT `/token`, session metadata and session data.
- SQLite persistence for users and recommendation history.
- Home, Party and Jewelry planners.
- Optional jewelry outfit image upload.
- Gemini multimodal calls through the official `google-genai` Python SDK.
- JSON-oriented AI output parsing and validation.
- No-live-API fallback catalog using Amazon, Flipkart, IKEA, Swiggy, Zomato and OYO search links.
- History page and dashboard.
- Automated API/service tests.

## Quick start

### Windows PowerShell

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
# edit .env and set GEMINI_API_KEY if you want live Gemini recommendations
uvicorn app.main:app --reload
```

Open http://127.0.0.1:8000

### Run tests

```powershell
pytest -q
```

### API documentation

- Swagger: http://127.0.0.1:8000/docs
- ReDoc: http://127.0.0.1:8000/redoc

## Gemini setup

Put your API key in `.env`:

```env
GEMINI_API_KEY=your-key
USE_GEMINI=true
GEMINI_MODEL=gemini-1.5-flash
```

If the configured model is unavailable, the app automatically falls back to local deterministic recommendations instead of crashing.

## Production notes

- Replace the development `SECRET_KEY`.
- Use PostgreSQL or another production database.
- Store uploads in object storage rather than local disk.
- Add HTTPS, rate limiting, CSRF protection appropriate to the deployment topology, and a secrets manager.
- For live product inventory/pricing, integrate authorized retailer APIs rather than scraping pages.
