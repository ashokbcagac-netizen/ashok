from tests.conftest import client
import uuid

def test_register_and_login():
    email=f"{uuid.uuid4().hex}@example.com"
    r=client.post('/api/register',json={'email':email,'full_name':'Test User','password':'password123'})
    assert r.status_code==200
    r=client.post('/api/login',data={'email':email,'password':'password123'})
    assert r.status_code==200
    assert 'access_token' in r.json()
    r=client.get('/api/session-info')
    assert r.status_code==200
    assert r.json()['user']['email']==email
