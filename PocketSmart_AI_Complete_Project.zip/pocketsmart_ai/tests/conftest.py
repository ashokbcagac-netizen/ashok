import os
os.environ["DATABASE_URL"] = "sqlite:///./data/test_pocketsmart.db"
os.environ["USE_GEMINI"] = "false"
from fastapi.testclient import TestClient
from app.main import app
from app.database import init_db

init_db()
client = TestClient(app)
