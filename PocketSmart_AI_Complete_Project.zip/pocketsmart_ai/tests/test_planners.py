from tests.conftest import client
import uuid

def auth():
    email=f"{uuid.uuid4().hex}@example.com"
    client.post('/api/register',json={'email':email,'full_name':'Planner User','password':'password123'})
    client.post('/api/login',data={'email':email,'password':'password123'})

def test_home_planner():
    auth(); r=client.post('/api/generate-home',data={'budget':'25000','rooms':'Living Room','style':'Modern','quantities':'{"lights":2}'})
    assert r.status_code==200
    assert r.json()['planner']=='home'

def test_party_planner():
    auth(); r=client.post('/api/generate-party',data={'budget':'20000','guests':'20','event_type':'Birthday','venue':'Home'})
    assert r.status_code==200
    assert r.json()['planner']=='party'

def test_jewelry_planner():
    auth(); r=client.post('/api/generate-jewelry',data={'budget':'5000','occasion':'Wedding','style':'Elegant'})
    assert r.status_code==200
    assert r.json()['planner']=='jewelry'
