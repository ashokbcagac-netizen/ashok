import json
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.dependencies import get_current_user
from app.models.user import User
from app.models.recommendation import RecommendationHistory

router = APIRouter(tags=["History"])

@router.get("/history")
def history(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    rows = db.query(RecommendationHistory).filter(RecommendationHistory.user_id == user.id).order_by(RecommendationHistory.created_at.desc()).all()
    return [{"id":r.id,"planner_type":r.planner_type,"budget":r.budget,"created_at":r.created_at.isoformat(),"result":json.loads(r.result_json)} for r in rows]

@router.get("/recommendations-details/{recommendation_id}")
def recommendation_details(recommendation_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    row = db.query(RecommendationHistory).filter(RecommendationHistory.id == recommendation_id, RecommendationHistory.user_id == user.id).first()
    if not row: raise HTTPException(404, "Recommendation not found")
    return {"id":row.id,"planner_type":row.planner_type,"budget":row.budget,"input":json.loads(row.input_json),"result":json.loads(row.result_json)}
