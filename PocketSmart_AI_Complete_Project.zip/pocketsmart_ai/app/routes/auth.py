from fastapi import APIRouter, Depends, Form, Request, Response, HTTPException
from fastapi.responses import RedirectResponse, JSONResponse
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from app.database import get_db
from app.dependencies import get_current_user
from app.models.user import User
from app.models.schemas import RegisterRequest, UserOut, SessionInfo
from app.utils.security import hash_password, verify_password, create_access_token

router = APIRouter(tags=["Authentication"])

def issue_cookie(response: Response, token: str):
    response.set_cookie("access_token", token, httponly=True, samesite="lax", secure=False, max_age=60*60*24)

@router.post("/register", response_model=UserOut)
def register(payload: RegisterRequest, db: Session = Depends(get_db)):
    if db.query(User).filter(User.email == payload.email.lower()).first():
        raise HTTPException(409, "Email is already registered")
    user = User(email=payload.email.lower(), full_name=payload.full_name.strip(), password_hash=hash_password(payload.password))
    db.add(user); db.commit(); db.refresh(user)
    return user

@router.post("/login")
def login(response: Response, email: str = Form(...), password: str = Form(...), db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == email.lower()).first()
    if not user or not verify_password(password, user.password_hash):
        raise HTTPException(401, "Invalid email or password")
    token = create_access_token(str(user.id))
    issue_cookie(response, token)
    return {"message":"Login successful", "access_token":token, "token_type":"bearer", "user":UserOut.model_validate(user).model_dump()}

@router.post("/token")
def token(form: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == form.username.lower()).first()
    if not user or not verify_password(form.password, user.password_hash):
        raise HTTPException(401, "Incorrect username or password")
    return {"access_token": create_access_token(str(user.id)), "token_type":"bearer"}

@router.get("/logout")
def logout():
    response = RedirectResponse("/login", status_code=303)
    response.delete_cookie("access_token")
    return response

@router.get("/session-info", response_model=SessionInfo)
def session_info(user: User = Depends(get_current_user)):
    return {"logged_in": True, "user": user}

@router.get("/session-data")
def session_data(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    from app.models.recommendation import RecommendationHistory
    count = db.query(RecommendationHistory).filter(RecommendationHistory.user_id == user.id).count()
    return {"user_id": user.id, "email": user.email, "recommendation_count": count}
