import json
import uuid
from pathlib import Path
from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from sqlalchemy.orm import Session
from app.config import BASE_DIR, settings
from app.database import get_db
from app.dependencies import get_current_user
from app.models.user import User
from app.models.recommendation import RecommendationHistory
from app.models.schemas import RecommendationResponse
from app.services.recommendation import generate_recommendation

router = APIRouter(tags=["Planners"])
UPLOAD_DIR = BASE_DIR / "uploads"
UPLOAD_DIR.mkdir(exist_ok=True)
ALLOWED = {"image/jpeg", "image/png", "image/webp"}

def save_history(db, user, planner, budget, payload, result):
    row = RecommendationHistory(user_id=user.id, planner_type=planner, budget=budget, input_json=json.dumps(payload), result_json=result.model_dump_json())
    db.add(row); db.commit()

def parse_json_field(value: str, default):
    try: return json.loads(value)
    except Exception: return default

@router.post("/generate-home", response_model=RecommendationResponse)
def generate_home(budget: float = Form(..., gt=0), rooms: str = Form("Living Room"), style: str = Form("Modern"), quantities: str = Form("{}"), user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    payload = {"budget":budget, "rooms":rooms, "style":style, "quantities":parse_json_field(quantities,{})}
    result = generate_recommendation("home", budget, payload)
    save_history(db, user, "home", budget, payload, result)
    return result

@router.post("/generate-party", response_model=RecommendationResponse)
def generate_party(budget: float = Form(..., gt=0), guests: int = Form(..., gt=0), event_type: str = Form("Birthday"), venue: str = Form("Home"), date: str = Form(""), user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    payload = {"budget":budget, "guests":guests, "event_type":event_type, "venue":venue, "date":date}
    result = generate_recommendation("party", budget, payload)
    save_history(db, user, "party", budget, payload, result)
    return result

@router.post("/generate-jewelry", response_model=RecommendationResponse)
async def generate_jewelry(budget: float = Form(..., gt=0), occasion: str = Form("Wedding"), style: str = Form("Elegant"), outfit_notes: str = Form(""), outfit_image: UploadFile | None = File(None), user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    image_path = None
    if outfit_image and outfit_image.filename:
        if outfit_image.content_type not in ALLOWED:
            raise HTTPException(400, "Only JPG, PNG or WEBP images are allowed")
        raw = await outfit_image.read()
        if len(raw) > settings.max_upload_mb * 1024 * 1024:
            raise HTTPException(413, "Image is too large")
        suffix = Path(outfit_image.filename).suffix.lower() or ".jpg"
        image_path = UPLOAD_DIR / f"{uuid.uuid4().hex}{suffix}"
        image_path.write_bytes(raw)
    payload = {"budget":budget, "occasion":occasion, "style":style, "outfit_notes":outfit_notes, "has_outfit_image": bool(image_path)}
    result = generate_recommendation("jewelry", budget, payload, image_path)
    save_history(db, user, "jewelry", budget, payload, result)
    if image_path:
        try: image_path.unlink(missing_ok=True)
        except Exception: pass
    return result
