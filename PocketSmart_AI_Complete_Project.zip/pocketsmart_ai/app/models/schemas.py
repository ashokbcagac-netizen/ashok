from pydantic import BaseModel, Field, EmailStr, ConfigDict
from typing import Any

class RegisterRequest(BaseModel):
    email: EmailStr
    full_name: str = Field(min_length=2, max_length=120)
    password: str = Field(min_length=8, max_length=128)

class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    email: EmailStr
    full_name: str
    is_active: bool

class RecommendationItem(BaseModel):
    name: str
    category: str
    platform: str
    estimated_price: float = Field(ge=0)
    currency: str = "INR"
    reason: str
    url: str

class RecommendationResponse(BaseModel):
    planner: str
    budget: float
    allocated_total: float
    summary: str
    allocations: dict[str, float]
    recommendations: list[RecommendationItem]
    source: str
    notes: list[str] = []

class SessionInfo(BaseModel):
    logged_in: bool
    user: UserOut | None = None

class HistoryOut(BaseModel):
    id: int
    planner_type: str
    budget: float
    created_at: str
    result: dict[str, Any]
