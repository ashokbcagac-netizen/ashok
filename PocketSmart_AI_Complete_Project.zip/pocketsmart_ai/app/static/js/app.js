function money(n){return `₹${Number(n||0).toLocaleString('en-IN')}`}
function renderResults(data){
 const el=document.getElementById('results');
 el.innerHTML=`<div class="result-head"><div><span class="pill">${data.source}</span><h2>Your plan</h2><p>${data.summary}</p></div><strong>${money(data.allocated_total)} / ${money(data.budget)}</strong></div><div class="recommendations">${data.recommendations.map(i=>`<article class="recommendation"><div><span class="pill">${i.platform}</span><h3>${i.name}</h3><p>${i.category} · ${i.reason}</p></div><strong>${money(i.estimated_price)}</strong><a target="_blank" rel="noopener" href="${i.url}">Search platform →</a></article>`).join('')}</div>${data.notes?.length?`<div class="notes">${data.notes.map(n=>`<p>• ${n}</p>`).join('')}</div>`:''}`
}
function bindPlannerForm(endpoint){
 const form=document.getElementById('plannerForm');
 form.addEventListener('submit',async e=>{e.preventDefault();document.getElementById('message').textContent='Generating your plan…';const r=await fetch(endpoint,{method:'POST',body:new FormData(form)});const d=await r.json();if(r.ok){document.getElementById('message').textContent='';renderResults(d)}else{if(r.status===401)location.href='/login';document.getElementById('message').textContent=d.detail||'Could not generate recommendations.'}})
}
