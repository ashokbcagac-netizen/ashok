from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent.parent

class Settings(BaseSettings):
    app_name: str = "PocketSmart AI"
    environment: str = "development"
    secret_key: str = "dev-only-change-me"
    access_token_expire_minutes: int = 1440
    database_url: str = "sqlite:///./data/pocketsmart.db"
    gemini_api_key: str | None = None
    gemini_model: str = "gemini-1.5-flash"
    use_gemini: bool = True
    frontend_origins: str = "http://127.0.0.1:8000,http://localhost:8000"
    max_upload_mb: int = 5

    model_config = SettingsConfigDict(env_file=BASE_DIR / ".env", env_file_encoding="utf-8", extra="ignore")

    @property
    def origins(self) -> list[str]:
        return [x.strip() for x in self.frontend_origins.split(",") if x.strip()]

settings = Settings()
