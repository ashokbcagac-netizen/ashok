from contextlib import asynccontextmanager
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from app.config import settings, BASE_DIR
from app.database import init_db
from app.routes.auth import router as auth_router
from app.routes.planners import router as planner_router
from app.routes.history import router as history_router

@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    yield

app = FastAPI(title=settings.app_name, version="1.0.0", description="Budget-aware AI recommendation assistant", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=settings.origins, allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "app" / "static")), name="static")
templates = Jinja2Templates(directory=str(BASE_DIR / "app" / "templates"))
app.include_router(auth_router, prefix="/api")
app.include_router(planner_router, prefix="/api")
app.include_router(history_router, prefix="/api")

@app.get("/health")
def health(): return {"status":"ok","service":settings.app_name}

@app.get("/", response_class=HTMLResponse)
def home(request: Request): return templates.TemplateResponse("index.html", {"request":request})

@app.get("/register", response_class=HTMLResponse)
def register_page(request: Request): return templates.TemplateResponse("register.html", {"request":request})

@app.get("/login", response_class=HTMLResponse)
def login_page(request: Request): return templates.TemplateResponse("login.html", {"request":request})

@app.get("/dashboard", response_class=HTMLResponse)
def dashboard(request: Request): return templates.TemplateResponse("dashboard.html", {"request":request})

@app.get("/home-planner", response_class=HTMLResponse)
def home_planner(request: Request): return templates.TemplateResponse("home_planner.html", {"request":request})

@app.get("/party-planner", response_class=HTMLResponse)
def party_planner(request: Request): return templates.TemplateResponse("party_planner.html", {"request":request})

@app.get("/jewelry-planner", response_class=HTMLResponse)
def jewelry_planner(request: Request): return templates.TemplateResponse("jewelry_planner.html", {"request":request})

@app.get("/history", response_class=HTMLResponse)
def history_page(request: Request): return templates.TemplateResponse("history.html", {"request":request})

@app.get("/testimonials", response_class=HTMLResponse)
def testimonials(request: Request): return templates.TemplateResponse("testimonials.html", {"request":request})
