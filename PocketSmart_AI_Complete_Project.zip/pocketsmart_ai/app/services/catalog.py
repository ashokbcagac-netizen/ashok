from urllib.parse import quote_plus

CATALOG = {
    "home": [
        {"name":"Minimalist LED Ceiling Light", "category":"lighting", "platform":"Amazon", "price":1899, "query":"minimalist LED ceiling light"},
        {"name":"Scandinavian 4-Seater Dining Table", "category":"furniture", "platform":"IKEA", "price":12999, "query":"4 seater dining table"},
        {"name":"Modern Area Rug", "category":"decor", "platform":"Flipkart", "price":2499, "query":"modern area rug"},
        {"name":"Energy Efficient Ceiling Fan", "category":"lighting", "platform":"Amazon", "price":3299, "query":"energy efficient ceiling fan"},
        {"name":"Compact Storage Cabinet", "category":"storage", "platform":"IKEA", "price":6999, "query":"compact storage cabinet"},
        {"name":"Wall Art Set", "category":"decor", "platform":"Flipkart", "price":1599, "query":"wall art set"},
    ],
    "party": [
        {"name":"Catering Package for Small Events", "category":"catering", "platform":"Zomato", "price":6500, "query":"party catering"},
        {"name":"Party Food Delivery Package", "category":"catering", "platform":"Swiggy", "price":5500, "query":"party food"},
        {"name":"Birthday Decoration Kit", "category":"decoration", "platform":"Amazon", "price":1800, "query":"birthday decoration kit"},
        {"name":"Event Tableware Set", "category":"decoration", "platform":"Flipkart", "price":2200, "query":"event tableware set"},
        {"name":"Budget Stay / Guest Rooms", "category":"accommodation", "platform":"OYO", "price":4500, "query":"budget hotel"},
    ],
    "jewelry": [
        {"name":"Minimal Gold-Tone Necklace Set", "category":"necklace", "platform":"Amazon", "price":1299, "query":"minimal gold tone necklace set"},
        {"name":"Classic Pearl Earrings", "category":"earrings", "platform":"Flipkart", "price":999, "query":"classic pearl earrings"},
        {"name":"Statement Kundan Earrings", "category":"earrings", "platform":"Amazon", "price":1899, "query":"kundan earrings"},
        {"name":"Delicate Bracelet", "category":"bracelet", "platform":"Flipkart", "price":799, "query":"delicate bracelet"},
    ],
}

BASE_URLS = {
    "Amazon": "https://www.amazon.in/s?k=",
    "Flipkart": "https://www.flipkart.com/search?q=",
    "IKEA": "https://www.ikea.com/in/en/search/?q=",
    "Swiggy": "https://www.swiggy.com/search?query=",
    "Zomato": "https://www.zomato.com/search?q=",
    "OYO": "https://www.oyorooms.com/search?location=",
}

def fallback_recommendations(planner: str, budget: float, preferences: dict) -> dict:
    items = CATALOG[planner]
    chosen = []
    remaining = budget
    for item in items:
        if item["price"] <= remaining * 0.85 or not chosen:
            chosen.append(item)
            remaining -= item["price"]
        if len(chosen) >= 6:
            break
    if not chosen:
        chosen = sorted(items, key=lambda x: x["price"])[:3]
    total = sum(i["price"] for i in chosen)
    return {
        "planner": planner,
        "budget": budget,
        "allocated_total": total,
        "summary": "Fallback recommendations generated from the built-in demo catalog. Prices are estimates, not live inventory.",
        "allocations": {i["category"]: i["price"] for i in chosen},
        "recommendations": [
            {
                "name": i["name"], "category": i["category"], "platform": i["platform"],
                "estimated_price": i["price"], "currency":"INR",
                "reason": f"Fits the available budget and the requested {planner} planning context.",
                "url": BASE_URLS[i["platform"]] + quote_plus(i["query"]),
            } for i in chosen
        ],
        "source": "fallback-demo-catalog",
        "notes": ["Retail prices and availability must be verified on the linked platform."]
    }
