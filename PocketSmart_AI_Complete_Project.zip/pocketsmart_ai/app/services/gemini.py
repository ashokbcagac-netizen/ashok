import json
import logging
from pathlib import Path
from google import genai
from google.genai import types
from app.config import settings
from app.services.prompts import home_prompt, party_prompt, jewelry_prompt

logger = logging.getLogger(__name__)

class GeminiService:
    def __init__(self):
        self.client = genai.Client(api_key=settings.gemini_api_key) if settings.gemini_api_key and settings.use_gemini else None

    def available(self) -> bool:
        return self.client is not None

    def _generate(self, prompt: str, image_path: Path | None = None) -> dict:
        if not self.client:
            raise RuntimeError("Gemini is not configured")
        contents = [prompt]
        if image_path:
            mime = "image/jpeg" if image_path.suffix.lower() in {".jpg", ".jpeg"} else "image/png"
            contents.append(types.Part.from_bytes(data=image_path.read_bytes(), mime_type=mime))
        response = self.client.models.generate_content(
            model=settings.gemini_model,
            contents=contents,
            config=types.GenerateContentConfig(temperature=0.3, response_mime_type="application/json")
        )
        text = response.text or "{}"
        return json.loads(text)

    def recommend(self, planner: str, data: dict, image_path: Path | None = None) -> dict:
        prompts = {"home": home_prompt, "party": party_prompt, "jewelry": jewelry_prompt}
        return self._generate(prompts[planner](data), image_path)

service = GeminiService()
