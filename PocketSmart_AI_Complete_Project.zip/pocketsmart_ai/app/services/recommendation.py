from pathlib import Path
from pydantic import ValidationError
from app.models.schemas import RecommendationResponse
from app.services.catalog import fallback_recommendations
from app.services.gemini import service as gemini_service

def generate_recommendation(planner: str, budget: float, data: dict, image_path: Path | None = None) -> RecommendationResponse:
    try:
        if gemini_service.available():
            result = gemini_service.recommend(planner, data, image_path)
            result["planner"] = planner
            result["budget"] = budget
            result["source"] = "gemini"
            return RecommendationResponse.model_validate(result)
    except (Exception, ValidationError):
        pass
    return RecommendationResponse.model_validate(fallback_recommendations(planner, budget, data))
