import json

def base_rules() -> str:
    return '''Return ONLY valid JSON. Do not use markdown fences. Currency is INR. Do not invent live inventory, exact stock, reviews, or exact current prices. Treat prices as estimates. Use platform search URLs rather than pretending to have live product links. Keep the total at or below the user's budget when practical. JSON schema: {"planner": string, "budget": number, "allocated_total": number, "summary": string, "allocations": object, "recommendations": [{"name":string,"category":string,"platform":string,"estimated_price":number,"currency":"INR","reason":string,"url":string}],"source":"gemini","notes":[string]}'''

def home_prompt(data: dict) -> str:
    return f'''You are PocketSmart AI's Home Interior budget planner.
User data:
{json.dumps(data, indent=2)}
Recommend a balanced set of furniture, decor and lighting based on rooms, quantities, style and budget. Mention Amazon, Flipkart or IKEA where appropriate. {base_rules()}'''

def party_prompt(data: dict) -> str:
    return f'''You are PocketSmart AI's Party budget planner.
User data:
{json.dumps(data, indent=2)}
Allocate the budget across catering, venue/accommodation where relevant, decoration and entertainment. Use Swiggy, Zomato, OYO, Amazon or Flipkart where appropriate. {base_rules()}'''

def jewelry_prompt(data: dict) -> str:
    return f'''You are PocketSmart AI's Jewelry budget planner.
User data:
{json.dumps(data, indent=2)}
Suggest jewelry by occasion and style, considering the outfit analysis if provided. Use Amazon and Flipkart where appropriate. {base_rules()}'''
